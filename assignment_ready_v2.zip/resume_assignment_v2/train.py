
import argparse, os, pandas as pd, joblib
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import classification_report

def main(args):
    df = pd.read_csv(args.data)
    le = LabelEncoder()
    y = le.fit_transform(df["Category"])
    X_train, X_test, y_train, y_test = train_test_split(df["Resume"], y, test_size=0.2, random_state=42, stratify=y)
    pipe = Pipeline([("tfidf", TfidfVectorizer(max_features=5000, ngram_range=(1,2))),
                     ("clf", LogisticRegression(max_iter=300))])
    pipe.fit(X_train, y_train)
    y_pred = pipe.predict(X_test)
    print(classification_report(y_test, y_pred, target_names=le.classes_))
    os.makedirs(args.model_dir, exist_ok=True)
    joblib.dump(pipe, os.path.join(args.model_dir, "model.joblib"))
    joblib.dump(le, os.path.join(args.model_dir, "label_encoder.joblib"))
    print("✅ Model saved.")

if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--data", required=True)
    p.add_argument("--model_dir", default="models")
    main(p.parse_args())
