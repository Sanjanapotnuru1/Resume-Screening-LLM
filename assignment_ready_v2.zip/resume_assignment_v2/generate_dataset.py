
import pandas as pd
import random

categories = {
    "Data Scientist": ["Python", "Pandas", "NumPy", "Scikit-learn", "TensorFlow", "ML models", "Data Visualization"],
    "Web Developer": ["HTML", "CSS", "JavaScript", "React", "Node.js", "Django", "Flask", "REST APIs"],
    "AI Engineer": ["PyTorch", "TensorFlow", "NLP", "Computer Vision", "Reinforcement Learning", "Deep Learning"],
    "HR": ["Recruitment", "Payroll", "Onboarding", "Employee Engagement", "Performance Review"],
    "Project Manager": ["Agile", "Scrum", "Risk Management", "Stakeholder Management", "Project Planning"],
    "Software Engineer": ["C++", "Java", "Python", "System Design", "Algorithms", "Data Structures"],
    "DevOps Engineer": ["CI/CD", "Docker", "Kubernetes", "Jenkins", "AWS", "Terraform", "Linux"],
    "Business Analyst": ["Data Analysis", "SQL", "Reporting", "Requirement Gathering", "UML", "Tableau"],
    "Marketing Specialist": ["SEO", "Google Ads", "Social Media Marketing", "Content Strategy", "Brand Awareness"],
    "Graphic Designer": ["Adobe Photoshop", "Illustrator", "UI/UX", "Figma", "Logo Design", "Creative Design"]
}

data = []
for category, skills in categories.items():
    for i in range(10):  # 10 samples each
        sample = f"{category} with experience in " + ", ".join(random.sample(skills, k=min(4, len(skills)))) + f". Project {i+1}."
        data.append((sample, category))

df = pd.DataFrame(data, columns=["Resume", "Category"])
df.to_csv("synthetic_resume_dataset.csv", index=False)
print("✅ Dataset created with", len(df), "samples across", len(categories), "fields.")
