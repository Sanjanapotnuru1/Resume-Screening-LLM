
import os, subprocess, sys, time

def ensure_installed():
    pkgs=["streamlit","pyngrok==6.1.0","scikit-learn","pandas","numpy","joblib","PyPDF2","python-docx"]
    subprocess.check_call([sys.executable,"-m","pip","install","-q"]+pkgs)

def start_streamlit():
    return subprocess.Popen([sys.executable,"-m","streamlit","run","app.py","--server.port","8501","--server.address","0.0.0.0"], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)

def start_ngrok():
    from pyngrok import ngrok, conf
    token=os.environ.get("NGROK_AUTH_TOKEN")
    if token: conf.get_default().auth_token=token
    return ngrok.connect(8501,"http").public_url

def main():
    ensure_installed()
    p=start_streamlit(); time.sleep(5)
    url=start_ngrok(); print("Your app is live at:",url)
    try:
        while True:
            l=p.stdout.readline()
            if not l: time.sleep(0.5); continue
            print(l,end="")
    except KeyboardInterrupt: pass

if __name__=="__main__": main()
