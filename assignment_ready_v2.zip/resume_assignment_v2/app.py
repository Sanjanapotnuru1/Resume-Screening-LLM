
import streamlit as st
import pandas as pd
import joblib
import PyPDF2
import docx

# -----------------------------
# Helper functions
# -----------------------------
def extract_text_from_pdf(file):
    text = ""
    pdf_reader = PyPDF2.PdfReader(file)
    for page in pdf_reader.pages:
        text += page.extract_text() or ""
    return text

def extract_text_from_docx(file):
    doc = docx.Document(file)
    return "\n".join([para.text for para in doc.paragraphs if para.text.strip()])

# -----------------------------
# Load Model
# -----------------------------
model = joblib.load("models/model.joblib")
le = joblib.load("models/label_encoder.joblib")

st.set_page_config(page_title="Resume Screening AI", page_icon="🧠", layout="wide")
st.title("🧠 Resume Screening AI Assistant")

tab1, tab2 = st.tabs(["Single Resume", "Batch Upload"])

# -----------------------------
# Single Resume
# -----------------------------
with tab1:
    uploaded_file = st.file_uploader("Upload Resume (PDF/DOCX/TXT)", type=["pdf", "docx", "txt"])
    resume_text = ""

    if uploaded_file is not None:
        if uploaded_file.type == "application/pdf":
            resume_text = extract_text_from_pdf(uploaded_file)
        elif uploaded_file.type == "application/vnd.openxmlformats-officedocument.wordprocessingml.document":
            resume_text = extract_text_from_docx(uploaded_file)
        elif uploaded_file.type == "text/plain":
            resume_text = uploaded_file.read().decode("utf-8")

        st.text_area("Extracted Resume Text", resume_text, height=200)

    if st.button("Predict"):
        if not resume_text.strip():
            st.error("Please upload or paste resume text.")
        else:
            pred = model.predict([resume_text])[0]
            st.success(f"Predicted Role: {le.inverse_transform([pred])[0]}")

# -----------------------------
# Batch Upload
# -----------------------------
with tab2:
    file = st.file_uploader("Upload CSV with Resume column", type="csv")
    if file is not None:
        df = pd.read_csv(file)
        if "Resume" not in df.columns:
            st.error("CSV must contain 'Resume' column")
        else:
            preds = model.predict(df["Resume"].tolist())
            df["PredictedCategory"] = le.inverse_transform(preds)
            st.dataframe(df)
            st.download_button("Download Results", df.to_csv(index=False).encode("utf-8"), "results.csv")
